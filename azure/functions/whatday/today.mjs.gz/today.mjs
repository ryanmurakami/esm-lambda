import moment from 'moment'

export default () => {
  return moment().format('MMM Do YYYY')
}
